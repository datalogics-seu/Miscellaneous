﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

/*
 * This sample demonstrates a basic PDF reconstruction workflow, converting a PDF file to PS and back to PDF. This process, 
 * known as refrying, is used for optimization, sanization, or "PDF problem fixing" purposes.
 *
 * -- To convert to the PDF to PS, this sample will use a print program built with the PDF Library SDK 
 *       called ExportToPS.exe.  Copy ExportToPS.exe to the PDF Library .NET binaries location
 * -- To convert the PS back to PDF, we will use the democonverter program from the PDF Converter SDK.
 *
 * Important: You will need to specify the locations of the SDKs in the strings below and recompile.
 * 
 * To run, this program accepts two input parameters:
 * -- inputFile or inputFolder  (absolute path required)
 * -- outputFolder              (absolute path required)
 * Examples:
 *    PDFReconstruct.exe  c:\temp\input\test1.pdf  c:\temp\output  
 *    PDFReconstruct.exe  c:\temp\input  c:\temp\output
 * 
 * Disclaimer: Samples are designed for demonstration purposes and are not intended for production usage.
 *
 * Copyright (c) 2019, Datalogics, Inc. All rights reserved.
 */
namespace PDFReconstruct
{

    class Program
    {
        // Set the location of the PDF Library SDK binaries and the PDF Converter SDK \deliver folder here
        static String PDFLibraryLocation = "C:\\Datalogics\\APDFL15.0.4PlusP5h-x64\\DotNET\\Binaries";
        static String ExportToPSExecutable = PDFLibraryLocation + "\\ExportToPS.exe";
        static String PDFConverterLocation = "C:\\Datalogics\\PDFConverter1.1PlusP1m\\deliver";
        static String PDFConverterExecutable = PDFConverterLocation + "\\democonverter.exe";
        static String PDFConverterJobOptions = "Standard.joboptions";

        static void ProcessOneFile(String sInput, String outputFolder, ref int successCount, ref int failCount)
        {
            // **************************
            // Convert the PDF to PS
            // **************************
            String tempPSFile = sInput.Remove(sInput.Length - 4) + ".ps"; // this is a cheap way to do it.  Will not work if the file does not have a 4 char extension such as ".pdf"
            String ExportToPSArguments = sInput + " " + tempPSFile;
            // The ExportToPS.exe program takes an input file and temporary PS output file as arguments
            // When finished, the command line arguments will look something like this ...
            // String ExportToPSArguments = "c:\\temp\\input\\test1.pdf  c:\\temp\\output\\Test1.ps";

            Console.WriteLine("  -- Reconstructing {0} ", sInput);

            using (Process myProcess = new Process())
            {
                myProcess.StartInfo.WorkingDirectory = PDFLibraryLocation;
                myProcess.StartInfo.Arguments = ExportToPSArguments;
                myProcess.StartInfo.FileName = ExportToPSExecutable;
                //myProcess.StartInfo.CreateNoWindow = true;
                myProcess.StartInfo.UseShellExecute = false;
                myProcess.StartInfo.RedirectStandardOutput = true;
                myProcess.Start();
                myProcess.WaitForExit();  //lets wait here
                // Console.WriteLine(myProcess.StandardOutput.ReadToEnd()); //if you want to see the ExportToPDF console, uncomment this
                if (myProcess.ExitCode == 0)
                {
                    //Console.WriteLine("Successful conversion to PS ");
                }
                else
                {
                    Console.WriteLine("    Failed to convert {0} to PS ", sInput);
                    failCount++;
                    return;
                }
            }


            // **************************
            // Convert the PS back to PDF
            // **************************
            String PDFConverterBaseArguments = "-efi +n -v -r0 -P " + PDFConverterLocation + "\\ICCProfiles" + " -B " + PDFConverterLocation + "\\Settings\\" + PDFConverterJobOptions;
            String PDFConverterArguments = PDFConverterBaseArguments + " " + "-O " + outputFolder + " " +  tempPSFile;
            // When finished, the PDFConverter command line arguments will look something like this ...
            // String PDFConverterArguments = "-efi +n -v -r0 -P C:\\Datalogics\\PDFConverter1.1PlusP1m\\deliver\\ICCProfiles  -B C:\\Datalogics\\PDFConverter1.1PlusP1m\\deliver\\Settings\\Standard.joboptions -O c:\\temp\\output c:\\temp\\output\\Test1.ps";

            using (Process myProcess = new Process())
            {
                myProcess.StartInfo.WorkingDirectory = PDFConverterLocation;
                myProcess.StartInfo.Arguments = PDFConverterArguments;
                myProcess.StartInfo.FileName = PDFConverterExecutable;
                //myProcess.StartInfo.CreateNoWindow = true;
                myProcess.StartInfo.UseShellExecute = false;
                myProcess.StartInfo.RedirectStandardOutput = true;
                myProcess.Start();
                myProcess.WaitForExit();  //lets wait here
                // Console.WriteLine(myProcess.StandardOutput.ReadToEnd()); //if you want to see the PDF Converter console, uncomment this

                if (myProcess.ExitCode == 0)
                {
                    // Console.WriteLine("Successful conversion back to PDF ");
                    successCount++;
                }
                else
                {
                    Console.WriteLine("    Failed to convert {0} back to PDF ", tempPSFile);
                    failCount++;
                    return;
                }
                // delete the tempfile -- Check if file exists with its full path    
                if (File.Exists(tempPSFile))
                {
                    File.Delete(tempPSFile);
                }
            }
        }


        static void Main(string[] args)
        {
            String sInput = "";    
            String outputFolder = "";
            int successCount = 0, failCount = 0;

            if (args.Length > 0)
                sInput = args[0];
            if (args.Length > 1)
                outputFolder = args[1];

            if (args.Length < 2)
            {
                Console.WriteLine ("Incorrect number of arguments");
                Console.WriteLine("Usage:  PDFReconstruct.exe  c:\\temp\\inputFolder\\test1.pdf  c:\\temp\\outputFolder");
                Console.WriteLine("   or:  PDFReconstruct.exe  c:\\temp\\inputFolder  c:\\temp\\outputFolder");
                System.Environment.Exit(1);
            }

            // Do a small amount of error checking...
            // Console.WriteLine("In: " + sInput + "   Out: " + outputFolder);

            if ( !File.Exists(sInput) && !Directory.Exists(sInput) )
            {
                 Console.WriteLine("{0} is not a valid file or directory.", sInput);
                 System.Environment.Exit(1);
            }

            if (!Directory.Exists(outputFolder))
            {
                 Console.WriteLine("{0} is not a valid directory.", outputFolder);
                 System.Environment.Exit(1);
            }

            // Start processing files...
            // When processing a folder, we are only looking for files with the .pdf extension.  
            // To work with ALL files, regardless of the extension, you would need to extend this a bit

            FileAttributes attr = File.GetAttributes(sInput);
            if ((attr & FileAttributes.Directory) == FileAttributes.Directory)
            {
                string[] fileEntries = Directory.GetFiles(sInput, "*.pdf");
                Console.WriteLine("Processing {0}  files in {1} ", fileEntries.Count(), sInput);
                foreach (string fileName in fileEntries)
                    ProcessOneFile(fileName, outputFolder, ref successCount, ref failCount);
            }
            else
            {
                Console.WriteLine("Processing one file: " + sInput);
                ProcessOneFile(sInput, outputFolder, ref successCount, ref failCount);
            }

            Console.WriteLine("Finished! {0}  files converted, {1} failed.", successCount, failCount);

         }
    }
}
